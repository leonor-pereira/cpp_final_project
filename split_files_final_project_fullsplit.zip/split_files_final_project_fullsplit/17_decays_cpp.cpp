// C++ final project: decays cpp file

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "4_quarks.h"
#include "5_lepton.h"
#include "6_electron.h"
#include "7_muon.h"
#include "8_tau.h"
#include "9_neutrino.h"
#include "10_scalar_boson.h"
#include "11_higgs_boson.h"
#include "12_vector_boson.h"
#include "13_w_boson.h"
#include "14_z_boson.h"
#include "15_gluon.h"
#include "16_photon.h"

void tau::get_tau_decay_products(std::string decay_flavour)
{
  if(flavour == "tau")
  {
    std::vector<std::shared_ptr<particle>> decay_products(3);

    if (decay_flavour == "up_down")
    {
      std::cout << "The tau decayed into an anti-up quark, a down quark and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antiup = std::make_shared<quark>("antiup");
      std::shared_ptr<particle> decayed_down = std::make_shared<quark>("down");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antiup->get_charge()) + (decayed_down->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antiup->get_lepton_number()) + (decayed_down->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antiup;
        decay_products.at(1) = decayed_down;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "up_strange")
    { 
      std::cout << "The tau decayed into an anti-up quark, an strange quark and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antiup = std::make_shared<quark>("antiup");
      std::shared_ptr<particle> decayed_strange = std::make_shared<quark>("strange");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antiup->get_charge()) + (decayed_strange->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antiup->get_lepton_number()) + (decayed_strange->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antiup;
        decay_products.at(1) = decayed_strange;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_down")
    {
      std::cout << "The tau decayed into an anti-charm quark, a down quark and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_anticharm = std::make_shared<quark>("anticharm");
      std::shared_ptr<particle> decayed_down = std::make_shared<quark>("down");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_anticharm->get_charge()) + (decayed_down->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_anticharm->get_lepton_number()) + (decayed_down->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_anticharm;
        decay_products.at(1) = decayed_down;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_strange")
    {
      std::cout << "The tau decayed into an anti-charm quark, a strange quark and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_anticharm = std::make_shared<quark>("anticharm");
      std::shared_ptr<particle> decayed_strange = std::make_shared<quark>("strange");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_anticharm->get_charge()) + (decayed_strange->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_anticharm->get_lepton_number()) + (decayed_strange->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_anticharm;
        decay_products.at(1) = decayed_strange;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "electron")
    {
      std::cout << "The tau decayed into an electron, an anti-electron neutrino and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_electron = std::make_shared<electron>("electron");
      std::shared_ptr<particle> decayed_antielectronneutrino = std::make_shared<neutrino>("antielectron_neutrino");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_electron->get_charge()) + (decayed_antielectronneutrino->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_electron->get_lepton_number()) + (decayed_antielectronneutrino->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_electron;
        decay_products.at(1) = decayed_antielectronneutrino;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "muon")
    {
      std::cout << "The tau decayed into an muon, an anti-muon neutrino and a tau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_muon = std::make_shared<muon>("muon");
      std::shared_ptr<particle> decayed_antimuonneutrino = std::make_shared<neutrino>("antimuon_neutrino");
      std::shared_ptr<particle> decayed_tauneutrino = std::make_shared<neutrino>("tau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_muon->get_charge()) + (decayed_antimuonneutrino->get_charge()) + (decayed_tauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_muon->get_lepton_number()) + (decayed_antimuonneutrino->get_lepton_number()) + (decayed_tauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_muon;
        decay_products.at(1) = decayed_antimuonneutrino;
        decay_products.at(2) = decayed_tauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else
    {
      std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
    }
  }
  else if(flavour == "antitau"){
    std::vector<std::shared_ptr<particle>> decay_products(3);

    if (decay_flavour == "up_down")
    {
      std::cout << "The antitau decayed into an up quark, an antidown quark and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_up = std::make_shared<quark>("up");
      std::shared_ptr<particle> decayed_antidown = std::make_shared<quark>("antidown");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_up->get_charge()) + (decayed_antidown->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_up->get_lepton_number()) + (decayed_antidown->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_up;
        decay_products.at(1) = decayed_antidown;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "up_strange")
    {
      std::cout << "The antitau decayed into an up quark, an antistrange quark and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_up = std::make_shared<quark>("up");
      std::shared_ptr<particle> decayed_antistrange = std::make_shared<quark>("antistrange");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_up->get_charge()) + (decayed_antistrange->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_up->get_lepton_number()) + (decayed_antistrange->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_up;
        decay_products.at(1) = decayed_antistrange;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_down")
    {
      std::cout << "The antitau decayed into a charm quark, an antidown quark and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_charm = std::make_shared<quark>("charm");
      std::shared_ptr<particle> decayed_antidown = std::make_shared<quark>("antidown");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_charm->get_charge()) + (decayed_antidown->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_charm->get_lepton_number()) + (decayed_antidown->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_charm;
        decay_products.at(1) = decayed_antidown;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_strange")
    {
      std::cout << "The antitau decayed into a charm quark, an antistrange quark and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_charm = std::make_shared<quark>("charm");
      std::shared_ptr<particle> decayed_antistrange = std::make_shared<quark>("antistrange");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_charm->get_charge()) + (decayed_antistrange->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_charm->get_lepton_number()) + (decayed_antistrange->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_charm;
        decay_products.at(1) = decayed_antistrange;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "electron")
    {
      std::cout << "The antitau decayed into an antielectron, an electron neutrino and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antielectron = std::make_shared<electron>("antielectron");
      std::shared_ptr<particle> decayed_electronneutrino = std::make_shared<neutrino>("electron_neutrino");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antielectron->get_charge()) + (decayed_electronneutrino->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antielectron->get_lepton_number()) + (decayed_electronneutrino->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antielectron;
        decay_products.at(1) = decayed_electronneutrino;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "muon")
    {
      std::cout << "The antitau decayed into an antimuon, a muon neutrino and an antitau neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antimuon = std::make_shared<electron>("antimuon");
      std::shared_ptr<particle> decayed_muonneutrino = std::make_shared<neutrino>("muon_neutrino");
      std::shared_ptr<particle> decayed_antitauneutrino = std::make_shared<neutrino>("antitau_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antimuon->get_charge()) + (decayed_muonneutrino->get_charge()) + (decayed_antitauneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antimuon->get_lepton_number()) + (decayed_muonneutrino->get_lepton_number()) + (decayed_antitauneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antimuon;
        decay_products.at(1) = decayed_muonneutrino;
        decay_products.at(2) = decayed_antitauneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else
    {
      std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
    }
  }
  else
  {
    std::cout << "No flavour has been assigned to the tau particle. Please assign either tau or antitau to this particle. " << std::endl;
  }
};

void higgs_boson::get_higgs_decay_products(std::string decay_flavour)
{
  std::vector<std::shared_ptr<particle>> decay_products(2);

  if(decay_flavour == "ZZ")
  {
    std::cout << "The Higgs boson decayed into two Z bosons. " << std::endl;

    std::shared_ptr<particle> decayed_zboson1 = std::make_shared<z_boson>("default");
    std::shared_ptr<particle> decayed_zboson2 = std::make_shared<z_boson>("default");

    float charge_before_decay, charge_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_zboson1->get_charge()) + (decayed_zboson2->get_charge());

    // consistency check with charge conservation
    if(charge_before_decay == charge_post_decay)
    {
      decay_products.at(0) = decayed_zboson1;
      decay_products.at(1) = decayed_zboson2;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Charge is not being conserved. The decay was unsuccessful. " << std::endl;
    }
  }
  else if(decay_flavour == "WW")
  {
    std::cout << "The Higgs boson decayed into a W+ boson and a W- boson. " << std::endl;

    std::shared_ptr<particle> decayed_wplus_boson = std::make_shared<w_boson>("w_plus");
    std::shared_ptr<particle> decayed_wminus_boson = std::make_shared<w_boson>("w_minus");

    float charge_before_decay, charge_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_wplus_boson->get_charge()) + (decayed_wminus_boson->get_charge());

    // consistency check with charge conservation
    if(charge_before_decay == charge_post_decay)
    {
      decay_products.at(0) = decayed_wplus_boson;
      decay_products.at(1) = decayed_wminus_boson;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Charge is not being conserved. The decay was unsuccessful. " << std::endl;
    }
  }
  else if(decay_flavour == "gammagamma")
  {
    std::cout << "The Higgs boson decayed into two photons. " << std::endl;

    std::shared_ptr<particle> decayed_photon1 = std::make_shared<photon>("default");
    std::shared_ptr<particle> decayed_photon2 = std::make_shared<photon>("default");

    float charge_before_decay, charge_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_photon1->get_charge()) + (decayed_photon2->get_charge());

    // consistency check with charge conservation
    if(charge_before_decay == charge_post_decay)
    {
      decay_products.at(0) = decayed_photon1;
      decay_products.at(1) = decayed_photon2;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Charge is not being conserved. The decay was unsuccessful. " << std::endl;
    }
  }
  else if(decay_flavour == "bottom_bottom")
  {
    std::cout << "The Higgs boson decayed into a bottom and an antibottom quark. " << std::endl;

    std::shared_ptr<particle> decayed_bottom = std::make_shared<quark>("bottom");
    std::shared_ptr<particle> decayed_antibottom = std::make_shared<quark>("antibottom");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_bottom->get_charge()) + (decayed_antibottom->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_bottom->get_baryon_number()) + (decayed_antibottom->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_bottom;
      decay_products.at(1) = decayed_antibottom;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either charge or baryon number is not being conserved. The decay was unsuccessful. " << std::endl;
    }
  }
  else
  {
    std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
  }
};

void w_boson::get_w_decay_products(std::string decay_flavour)
{
  std::vector<std::shared_ptr<particle>> decay_products(2);

  if(flavour == "w_minus")
  {
    if (decay_flavour == "up_down")
    {
      std::cout << "The W- boson decayed into an anti-up quark and a down quark. " << std::endl;
      std::shared_ptr<particle> decayed_antiup = std::make_shared<quark>("antiup");
      std::shared_ptr<particle> decayed_down = std::make_shared<quark>("down");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antiup->get_charge()) + (decayed_down->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_antiup->get_baryon_number()) + (decayed_down->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_antiup;
        decay_products.at(1) = decayed_down;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "up_strange")
    { 
      std::cout << "The W- boson decayed into an anti-up quark and a strange quark. " << std::endl;
      std::shared_ptr<particle> decayed_antiup = std::make_shared<quark>("antiup");
      std::shared_ptr<particle> decayed_strange = std::make_shared<quark>("strange");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antiup->get_charge()) + (decayed_strange->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_antiup->get_baryon_number()) + (decayed_strange->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_antiup;
        decay_products.at(1) = decayed_strange;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_down")
    {
      std::cout << "The W- boson decayed into an anti-charm quark and a down quark. " << std::endl;
      std::shared_ptr<particle> decayed_anticharm = std::make_shared<quark>("anticharm");
      std::shared_ptr<particle> decayed_down = std::make_shared<quark>("down");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_anticharm->get_charge()) + (decayed_down->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_anticharm->get_baryon_number()) + (decayed_down->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_anticharm;
        decay_products.at(1) = decayed_down;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_strange")
    {
      std::cout << "The W- boson decayed into an anti-charm quark and a strange quark. " << std::endl;
      std::shared_ptr<particle> decayed_anticharm = std::make_shared<quark>("anticharm");
      std::shared_ptr<particle> decayed_strange = std::make_shared<quark>("strange");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_anticharm->get_charge()) + (decayed_strange->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_anticharm->get_baryon_number()) + (decayed_strange->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_anticharm;
        decay_products.at(1) = decayed_strange;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "electron")
    {
      std::cout << "The W- decayed into an electron and an anti-electron neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_electron = std::make_shared<electron>("electron");
      std::shared_ptr<particle> decayed_antielectronneutrino = std::make_shared<neutrino>("antielectron_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_electron->get_charge()) + (decayed_antielectronneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_electron->get_lepton_number()) + (decayed_antielectronneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_electron;
        decay_products.at(1) = decayed_antielectronneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "muon")
    {
      std::cout << "The W- decayed into a muon and an anti-muon neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_muon = std::make_shared<muon>("muon");
      std::shared_ptr<particle> decayed_antimuonneutrino = std::make_shared<neutrino>("antimuon_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_muon->get_charge()) + (decayed_antimuonneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_muon->get_lepton_number()) + (decayed_antimuonneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_muon;
        decay_products.at(1) = decayed_antimuonneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else
    {
      std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
    }
  }
  else if(flavour == "w_plus")
  {
    if (decay_flavour == "up_down")
    {
      std::cout << "The W+ boson decayed into an up quark and a antidown quark. " << std::endl;
      std::shared_ptr<particle> decayed_up = std::make_shared<quark>("up");
      std::shared_ptr<particle> decayed_antidown = std::make_shared<quark>("antidown");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_up->get_charge()) + (decayed_antidown->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_up->get_baryon_number()) + (decayed_antidown->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_up;
        decay_products.at(1) = decayed_antidown;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "up_strange")
    { 
      std::cout << "The W+ boson decayed into an up quark and an antistrange quark. " << std::endl;
      std::shared_ptr<particle> decayed_up = std::make_shared<quark>("up");
      std::shared_ptr<particle> decayed_antistrange = std::make_shared<quark>("antistrange");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_up->get_charge()) + (decayed_antistrange->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_up->get_baryon_number()) + (decayed_antistrange->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_up;
        decay_products.at(1) = decayed_antistrange;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_down")
    {
      std::cout << "The W+ boson decayed into a charm quark and an antidown quark. " << std::endl;
      std::shared_ptr<particle> decayed_charm = std::make_shared<quark>("charm");
      std::shared_ptr<particle> decayed_antidown = std::make_shared<quark>("antidown");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_charm->get_charge()) + (decayed_antidown->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_charm->get_baryon_number()) + (decayed_antidown->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_charm;
        decay_products.at(1) = decayed_antidown;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "charm_strange")
    {
      std::cout << "The W+ boson decayed into a charm quark and an antistrange quark. " << std::endl;
      std::shared_ptr<particle> decayed_charm = std::make_shared<quark>("charm");
      std::shared_ptr<particle> decayed_antistrange = std::make_shared<quark>("antistrange");

      float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_charm->get_charge()) + (decayed_antistrange->get_charge());
      baryon_number_before_decay = baryon_number;
      baryon_number_post_decay = (decayed_charm->get_baryon_number()) + (decayed_antistrange->get_baryon_number());

      // consistency check with charge and baryon number conservation
      if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
      {
        decay_products.at(0) = decayed_charm;
        decay_products.at(1) = decayed_antistrange;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "electron")
    {
      std::cout << "The W+ decayed into an antielectron and an electron neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antielectron = std::make_shared<electron>("antielectron");
      std::shared_ptr<particle> decayed_electronneutrino = std::make_shared<neutrino>("electron_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antielectron->get_charge()) + (decayed_electronneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antielectron->get_lepton_number()) + (decayed_electronneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antielectron;
        decay_products.at(1) = decayed_electronneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else if(decay_flavour == "muon")
    {
      std::cout << "The W+ decayed into an antimuon and a muon neutrino. " << std::endl;
      std::shared_ptr<particle> decayed_antimuon = std::make_shared<muon>("antimuon");
      std::shared_ptr<particle> decayed_muonneutrino = std::make_shared<neutrino>("muon_neutrino");

      float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
      charge_before_decay = charge;
      charge_post_decay = (decayed_antimuon->get_charge()) + (decayed_muonneutrino->get_charge());
      lepton_number_before_decay = lepton_number;
      lepton_number_post_decay = (decayed_antimuon->get_lepton_number()) + (decayed_muonneutrino->get_lepton_number());

      // consistency check with charge and lepton number conservation
      if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
      {
        decay_products.at(0) = decayed_antimuon;
        decay_products.at(1) = decayed_muonneutrino;

        decay_products_vector = decay_products;
      }
      else
      {
        std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
      }
    }
    else
    {
      std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
    }
  }
};

void z_boson::get_z_decay_products(std::string decay_flavour)
{
  std::vector<std::shared_ptr<particle>> decay_products(2);

  if(decay_flavour == "up_up")
  {
    std::cout << "The Z boson decayed into an up quark and an antiup quark. " << std::endl;
    std::shared_ptr<particle> decayed_up = std::make_shared<quark>("up");
    std::shared_ptr<particle> decayed_antiup = std::make_shared<quark>("antiup");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_up->get_charge()) + (decayed_antiup->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_up->get_baryon_number()) + (decayed_antiup->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_up;
      decay_products.at(1) = decayed_antiup;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    }    
  }
  else if(decay_flavour == "down_down")
  {
    std::cout << "The Z boson decayed into a down quark and an antidown quark. " << std::endl;
    std::shared_ptr<particle> decayed_down = std::make_shared<quark>("down");
    std::shared_ptr<particle> decayed_antidown = std::make_shared<quark>("antidown");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_down->get_charge()) + (decayed_antidown->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_down->get_baryon_number()) + (decayed_antidown->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_down;
      decay_products.at(1) = decayed_antidown;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    }  
  }
  else if(decay_flavour == "charm_charm")
  {
    std::cout << "The Z boson decayed into a charm quark and an anticharm quark. " << std::endl;
    std::shared_ptr<particle> decayed_charm = std::make_shared<quark>("charm");
    std::shared_ptr<particle> decayed_anticharm = std::make_shared<quark>("anticharm");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_charm->get_charge()) + (decayed_anticharm->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_charm->get_baryon_number()) + (decayed_anticharm->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_charm;
      decay_products.at(1) = decayed_anticharm;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    }  
  }
  else if(decay_flavour == "strange_strange")
  {
    std::cout << "The Z boson decayed into a strange quark and an antistrange quark. " << std::endl;
    std::shared_ptr<particle> decayed_strange = std::make_shared<quark>("strange");
    std::shared_ptr<particle> decayed_antistrange = std::make_shared<quark>("antistrange");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_strange->get_charge()) + (decayed_antistrange->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_strange->get_baryon_number()) + (decayed_antistrange->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_strange;
      decay_products.at(1) = decayed_antistrange;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    } 
  }
  else if(decay_flavour == "bottom_bottom")
  {
    std::cout << "The Z boson decayed into a bottom quark and an antibottom quark. " << std::endl;
    std::shared_ptr<particle> decayed_bottom = std::make_shared<quark>("bottom");
    std::shared_ptr<particle> decayed_antibottom = std::make_shared<quark>("antibottom");

    float charge_before_decay, charge_post_decay, baryon_number_before_decay, baryon_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_bottom->get_charge()) + (decayed_antibottom->get_charge());
    baryon_number_before_decay = baryon_number;
    baryon_number_post_decay = (decayed_bottom->get_baryon_number()) + (decayed_antibottom->get_baryon_number());

    // consistency check with charge and baryon number conservation
    if((charge_before_decay == charge_post_decay) && (baryon_number_before_decay == baryon_number_post_decay))
    {
      decay_products.at(0) = decayed_bottom;
      decay_products.at(1) = decayed_antibottom;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either baryon number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    } 
  }
  else if(decay_flavour == "electron")
  {
    std::cout << "The Z boson decayed into an electron and an antielectron. " << std::endl;
    std::shared_ptr<particle> decayed_electron = std::make_shared<electron>("electron");
    std::shared_ptr<particle> decayed_antielectron = std::make_shared<electron>("antielectron");

    float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_electron->get_charge()) + (decayed_antielectron->get_charge());
    lepton_number_before_decay = lepton_number;
    lepton_number_post_decay = (decayed_electron->get_lepton_number()) + (decayed_antielectron->get_lepton_number());

    // consistency check with charge and lepton number conservation
    if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
    {
      decay_products.at(0) = decayed_electron;
      decay_products.at(1) = decayed_antielectron;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    } 
  }
  else if(decay_flavour == "muon")
  {
    std::cout << "The Z boson decayed into a muon and an antimuon. " << std::endl;
    std::shared_ptr<particle> decayed_muon = std::make_shared<muon>("muon");
    std::shared_ptr<particle> decayed_antimuon = std::make_shared<muon>("antimuon");

    float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_muon->get_charge()) + (decayed_antimuon->get_charge());
    lepton_number_before_decay = lepton_number;
    lepton_number_post_decay = (decayed_muon->get_lepton_number()) + (decayed_antimuon->get_lepton_number());

    // consistency check with charge and lepton number conservation
    if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
    {
      decay_products.at(0) = decayed_muon;
      decay_products.at(1) = decayed_antimuon;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    } 
  }
  else if(decay_flavour == "tau")
  {
    std::cout << "The Z boson decayed into a tau and an antitau. " << std::endl;
    std::shared_ptr<particle> decayed_tau = std::make_shared<tau>("tau");
    std::shared_ptr<particle> decayed_antitau = std::make_shared<tau>("antitau");

    float charge_before_decay, charge_post_decay, lepton_number_before_decay, lepton_number_post_decay;
    charge_before_decay = charge;
    charge_post_decay = (decayed_tau->get_charge()) + (decayed_antitau->get_charge());
    lepton_number_before_decay = lepton_number;
    lepton_number_post_decay = (decayed_tau->get_lepton_number()) + (decayed_antitau->get_lepton_number());

    // consistency check with charge and lepton number conservation
    if((charge_before_decay == charge_post_decay) && (lepton_number_before_decay == lepton_number_post_decay))
    {
      decay_products.at(0) = decayed_tau;
      decay_products.at(1) = decayed_antitau;

      decay_products_vector = decay_products;
    }
    else
    {
      std::cout << "Either lepton number or charge are not being conserved. The decay was unsuccessful. " << std::endl;
    } 
  }
  else
  {
    std::cout << "An invalid flavour of decay was entered. The decay was unsuccessful. " << std::endl;
  }
};