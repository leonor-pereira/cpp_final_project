// C++ final project: abstract particle class header file

#ifndef PARTICLE_H
#define PARTICLE_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"

class particle
{
  protected:
    float mass;
    float charge;
    float spin;
    std::string flavour;
    float baryon_number;
    float lepton_number;
    four_momentum four_momentum_vector;
    bool antimatter_status;

  public:
    particle() = default;
    virtual ~particle() { };
    void set_mass(float mass_input);
    virtual void set_mass() = 0;
    virtual void set_charge(float charge_input) = 0;
    virtual void set_flavour(std::string flavour_input) = 0;
    void set_four_momenta(four_momentum particle_four_vector) {four_momentum_vector = particle_four_vector;};
    float get_mass() {return mass;};
    float get_charge() {return charge;};
    float get_spin() {return spin;};
    std::string get_flavour() {return flavour;};
    float get_baryon_number() {return baryon_number;};
    float get_lepton_number() {return lepton_number;};
    four_momentum get_four_momenta() {return four_momentum_vector;};
    bool get_antimatter_status() {return antimatter_status;};

    friend four_momentum operator+(four_momentum particle_1, four_momentum particle_2);

    friend std::vector<float> operator-(four_momentum particle_1, four_momentum particle_2);

    friend float dot_product(four_momentum particle_1, four_momentum particle_2);

    virtual void particle_printing_function() = 0;       //   p00pp00
};

#endif