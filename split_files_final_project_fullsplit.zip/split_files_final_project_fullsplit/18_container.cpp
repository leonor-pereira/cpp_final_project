// C++ final project: container class cpp file

#include "18_container.h"

void container::get_number_of_contents_by_particle_type()
{
  std::vector<int> number_of_quarks;
  std::vector<int> number_of_electrons;
  std::vector<int> number_of_muons;
  std::vector<int> number_of_taus;
  std::vector<int> number_of_neutrinos;
  std::vector<int> number_of_higgsbosons;
  std::vector<int> number_of_wbosons;
  std::vector<int> number_of_zbosons;
  std::vector<int> number_of_gluons;
  std::vector<int> number_of_photons;

  for(int i = 0; i < container_contents.size(); i++)
  {
    if((container_contents.at(i))->get_flavour() == "up" || (container_contents.at(i))->get_flavour() == "strange" || (container_contents.at(i))->get_flavour() == "top" || (container_contents.at(i))->get_flavour() == "down" || (container_contents.at(i))->get_flavour() == "strange" || (container_contents.at(i))->get_flavour() == "bottom" || (container_contents.at(i))->get_flavour() == "antiup" || (container_contents.at(i))->get_flavour() == "antistrange" || (container_contents.at(i))->get_flavour() == "antitop" || (container_contents.at(i))->get_flavour() == "antidown" || (container_contents.at(i))->get_flavour() == "antistrange" || (container_contents.at(i))->get_flavour() == "antibottom") {number_of_quarks.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "electron" || (container_contents.at(i))->get_flavour() == "antielectron") {number_of_electrons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "muon" || (container_contents.at(i))->get_flavour() == "antimuon") {number_of_muons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "tau" || (container_contents.at(i))->get_flavour() == "antitau") {number_of_taus.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "electron_neutrino" || (container_contents.at(i))->get_flavour() == "antielectron_neutrino" || (container_contents.at(i))->get_flavour() == "muon_neutrino" || (container_contents.at(i))->get_flavour() == "antimuon_neutrino" || (container_contents.at(i))->get_flavour() == "tau_neutrino" || (container_contents.at(i))->get_flavour() == "antitau_neutrino") {number_of_neutrinos.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "higgs_boson") {number_of_higgsbosons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "w_plus" || (container_contents.at(i))->get_flavour() == "w_minus") {number_of_wbosons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "Z_boson") {number_of_zbosons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "gluon") {number_of_gluons.push_back(1);}
    else if((container_contents.at(i))->get_flavour() == "photon") {number_of_photons.push_back(1);}
    else{std::cout << "No flavour was found. " << std::endl;}
  }

  std::cout << "Printing number of each particle type inside the container. " << std::endl;
  std::cout << "Number of quarks: " << number_of_quarks.size() << "; " << std::endl;
  std::cout << "Number of electrons: " << number_of_electrons.size() << "; " << std::endl;
  std::cout << "Number of muons: " << number_of_muons.size() << "; " << std::endl;
  std::cout << "Number of tau: " << number_of_taus.size() << "; " << std::endl;
  std::cout << "Number of neutrino: " << number_of_neutrinos.size() << "; " << std::endl;
  std::cout << "Number of Higgs bosons: " << number_of_higgsbosons.size() << "; " << std::endl;
  std::cout << "Number of W bosons: " << number_of_wbosons.size() << "; " << std::endl;
  std::cout << "Number of Z bosons: " << number_of_zbosons.size() << "; " << std::endl;
  std::cout << "Number of gluons: " << number_of_gluons.size() << "; " << std::endl;
  std::cout << "Number of photons: " << number_of_photons.size() << "; " << std::endl;
};

std::vector<float> container::four_momentum_container_sum()
{
  std::vector<float> summed_four_momentum(4);

  for(int i = 0; i < container_contents.size(); i++)
  {
    summed_four_momentum.at(0) += ((container_contents.at(i))->get_four_momenta()).get_energy();
    summed_four_momentum.at(1) += ((container_contents.at(i))->get_four_momenta()).get_px();
    summed_four_momentum.at(2) += ((container_contents.at(i))->get_four_momenta()).get_py();
    summed_four_momentum.at(3) += ((container_contents.at(i))->get_four_momenta()).get_pz();
  }

  std::cout << "Printing summed four-momentum vector. " << std::endl;
  std::cout << "Energy: " << summed_four_momentum.at(0) << "; px: " << summed_four_momentum.at(1) << "; py: " << summed_four_momentum.at(2) << "; pz: " << summed_four_momentum.at(3) << ". " << std::endl;

  return summed_four_momentum;
}