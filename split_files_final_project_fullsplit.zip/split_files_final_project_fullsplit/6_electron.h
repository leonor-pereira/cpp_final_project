// C++ final project: electron class header file

#ifndef ELECTRON_H
#define ELECTRON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "5_lepton.h"

const float electron_mass = 1.0; // to the nearest mev

class electron: public lepton
{
  private:
    std::shared_ptr<std::vector<float>> energy_deposited = std::make_shared<std::vector<float>>(4);
  public:
    electron() = default;
    electron(std::string particle_type);
    ~electron(){ };

    void set_energy_deposited(four_momentum four_vec, float em_1_deposited, float em_2_deposited, float had_1_deposited, float had_2_deposited);

    void set_flavour(std::string flavour_input) override ;

    void set_charge(float charge_input) override ;

    void set_mass() override ;

    std::shared_ptr<std::vector<float>> get_energy_deposited() {return energy_deposited;};

    void particle_printing_function() override ;
};

#endif