// C++ final project: photon class header file

#ifndef PHOTON_H
#define PHOTON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "12_vector_boson.h"

class photon: public vector_boson
{
  public:
    photon() = default;
    photon(std::string flavour_input);
    ~photon(){ };
    // member functions
    void set_charge(float charge_input) override ;
    
    void set_flavour(std::string flavour_input) override ;

    void set_mass() override ;

    void particle_printing_function() override ;
};

#endif