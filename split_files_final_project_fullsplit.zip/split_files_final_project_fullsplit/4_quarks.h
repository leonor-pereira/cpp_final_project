// C++ final project: quarks class header file

#ifndef QUARKS_H
#define QUARKS_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"

// mass values
const float up_mass = 2.0;
const float down_mass = 5.0;
const float charm_mass = 1.0*std::pow(10, 3);
const float strange_mass = 95.0;
const float top_mass = 173.0*std::pow(10, 3);
const float bottom_mass = 4.18*std::pow(10, 3);

class quark: public fermion
{
  private:
    std::string colour;
  public:
    quark() = default;
    // parameterised constructor
    quark(std::string flavour_input);
    ~quark(){ };

    // member functions
    void set_flavour(std::string flavour_input) override ;

    void set_charge(float charge_input) override ;

    void set_colour(std::string colour_input);

    void set_mass() override ;

    std::string get_colour() {return colour;}

    void particle_printing_function() override ;
};

#endif