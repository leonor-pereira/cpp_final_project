// C++ final project: muon class header file

#ifndef MUON_H
#define MUON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "5_lepton.h"

const float muon_mass = 106.0; // to the nearest mev

class muon: public lepton
{
  private:
    bool isolation;
  public:
    muon() = default;
    muon(std::string flavour_input);
    ~muon(){ };
    void set_isolation(bool isolation_value);

    void set_charge(float charge_input) override ;

    void set_flavour(std::string flavour_input) override ;

    void set_mass() override ;

    bool get_isolation() const {return isolation;};

    void particle_printing_function() override ;
};

#endif