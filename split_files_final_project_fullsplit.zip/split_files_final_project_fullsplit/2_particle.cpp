// C++ final project: abstract particle class cpp file

#include "2_particle.h"

// setters and getters
void particle::set_mass(float mass_input)
{
  if(mass_input >= 0)
  {
    mass = mass_input;
  }
};

// friend functions referring to four-momenta - overloading + operator
four_momentum operator+(four_momentum particle_1, four_momentum particle_2)
{
  four_momentum summed_four_vec;

  summed_four_vec.set_e(particle_1.get_energy() + particle_2.get_energy());
  summed_four_vec.set_px(particle_1.get_px() + particle_2.get_px());
  summed_four_vec.set_py(particle_1.get_py() + particle_2.get_py());
  summed_four_vec.set_pz(particle_1.get_pz() + particle_2.get_pz());
      
  return summed_four_vec;
};

// friend functions referring to four-momenta - overloading - operator
std::vector<float> operator-(four_momentum particle_1, four_momentum particle_2)
{
  std::vector<float> summed_four_vec(4);

  summed_four_vec.at(0) = particle_1.get_energy() - particle_2.get_energy();
  summed_four_vec.at(1) = particle_1.get_px() - particle_2.get_px();
  summed_four_vec.at(2) = particle_1.get_py() - particle_2.get_py();
  summed_four_vec.at(3) = particle_1.get_pz() - particle_2.get_pz();
      
  return summed_four_vec;
};

// function to calculate the dot product of two four-momenta
float dot_product(four_momentum particle_1, four_momentum particle_2){
  float dot_product_value;

  dot_product_value = (particle_1.get_energy()*particle_2.get_energy()) - (((particle_1.get_px())*(particle_2.get_px())) + ((particle_1.get_py())*(particle_2.get_py())) + ((particle_1.get_pz())*(particle_2.get_pz())));
  return dot_product_value;
};