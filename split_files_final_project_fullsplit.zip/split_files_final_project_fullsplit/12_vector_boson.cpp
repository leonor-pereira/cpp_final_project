// C++ final project: vector boson class header file

#include "12_vector_boson.h"

void vector_boson::particle_printing_function() 
{
  std::cout << "Printing four-momenta elements. Energy:" << four_momentum_vector.get_energy() << "; px: " << four_momentum_vector.get_px() << "; py: " << four_momentum_vector.get_py() << "; pz: " << four_momentum_vector.get_pz() << "." << std::endl;
  std::cout << "Flavour: " << get_flavour() << "; charge: " << get_charge() << "; spin: " << get_spin() << ". " << std::endl;
};