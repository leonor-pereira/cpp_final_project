// C++ final project: W boson class cpp file

#include "13_w_boson.h"

// parameterised constructor
w_boson::w_boson(std::string flavour_input)
{
  if(flavour_input == "w_plus")
  {
    flavour = flavour_input;
    charge = +1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else if(flavour_input == "w_minus")
  {
    flavour = flavour_input;
    charge = -1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to W plus. " << std::endl;
    flavour = "w_plus";
    charge = +1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
};

// setters and getters
void w_boson::set_flavour(std::string flavour_input)
{
  if(flavour_input == "w_plus")
  {
    flavour = flavour_input;
    charge = +1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else if(flavour_input == "w_minus")
  {
    flavour = flavour_input;
    charge = -1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to W plus. " << std::endl;
    flavour = "w_plus";
    charge = +1.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
};

void w_boson::set_charge(float charge_input)
{
  if(charge_input == +1)
  {
    charge = charge_input;
    flavour = "w_plus";
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else if(charge_input == -1)
  {
    charge = charge_input;
    flavour = "w_minus";
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;        
  }
};

void w_boson::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == w_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(88058, 10900, 29698, 18800);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void w_boson::particle_printing_function() 
{
  std::cout << "Printing W boson information. " << std::endl;
  vector_boson::particle_printing_function();
  std::cout << "Printing W boson decay information. " << std::endl;

  for(int i = 0; i < decay_products_vector.size(); i++)
  {
    std::cout << "Flavour: " << (decay_products_vector.at(i))->get_flavour() << "; charge: " << (decay_products_vector.at(i))->get_charge() << "; spin: " << (decay_products_vector.at(i))->get_spin() << ". " << std::endl;
  }
};