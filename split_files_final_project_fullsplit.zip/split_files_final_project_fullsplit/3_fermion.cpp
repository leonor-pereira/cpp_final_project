// C++ final project: fermion class cpp file

#include "3_fermion.h"

void fermion::particle_printing_function() 
{
  std::cout << "Printing four-momenta elements. Energy:" << four_momentum_vector.get_energy() << "; px: " << four_momentum_vector.get_px() << "; py: " << four_momentum_vector.get_py() << "; pz: " << four_momentum_vector.get_pz() << "." << std::endl;
  std::cout << "Charge: " << get_charge() << "; spin: " << get_spin() << ". " << std::endl;
};