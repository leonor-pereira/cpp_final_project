// C++ final project: tau class header file

#include "8_tau.h"

// parameterised constructor
tau::tau(std::string flavour_input)
{
  if (flavour_input == "tau")
  {
    flavour = flavour_input;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (flavour_input == "antitau")
  {
    flavour = flavour_input;
    charge = +1;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to tau. " << std::endl;
    charge = -1;
    flavour = "tau";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

// setters and getters
void tau::set_flavour(std::string flavour_input)
{
  if (flavour_input == "tau")
  {
    flavour = flavour_input;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (flavour_input == "antitau")
  {
    flavour = flavour_input;
    charge = +1;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to tau. " << std::endl;
    charge = -1;
    flavour = "tau";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

void tau::set_charge(float charge_input)
{
  if (charge_input==-1)
  {
    charge = charge_input;
    flavour = "tau";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (charge_input==+1)
  {
    charge = charge_input;
    flavour = "antitau";
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Charge value inputted is invalid. Setting charge to -1. " << std::endl;
    charge = -1;
    flavour = "tau";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;   
  }
};

void tau::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == tau_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(2130, 520, 300, 420);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void tau::particle_printing_function() 
{
  std::cout << "Printing tau information. " << std::endl;
  lepton::particle_printing_function();
  std::cout << "Flavour: " << get_flavour() << ". Printing tau decay information. " <<  std::endl;

  for(int i = 0; i < decay_products_vector.size(); i++)
  {
    std::cout << "Flavour: " << (decay_products_vector.at(i))->get_flavour() << "; charge: " << (decay_products_vector.at(i))->get_charge() << "; spin: " << (decay_products_vector.at(i))->get_spin() << ". " << std::endl;
  }
};