// C++ final project: main file

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "4_quarks.h"
#include "5_lepton.h"
#include "6_electron.h"
#include "7_muon.h"
#include "8_tau.h"
#include "9_neutrino.h"
#include "10_scalar_boson.h"
#include "11_higgs_boson.h"
#include "12_vector_boson.h"
#include "13_w_boson.h"
#include "14_z_boson.h"
#include "15_gluon.h"
#include "16_photon.h"
#include "18_container.h"

int main()
{
  // creating a particle of each kind
  std::shared_ptr<particle> up_quark1 = std::make_shared<quark>("up");
  std::shared_ptr<particle> antiup_quark1 = std::make_shared<quark>("antiup");
  std::shared_ptr<particle> electron1 = std::make_shared<electron>("electron");
  std::shared_ptr<particle> antielectron1 = std::make_shared<electron>("antielectron");
  std::shared_ptr<particle> muon1 = std::make_shared<muon>("muon");
  std::shared_ptr<particle> antimuon1 = std::make_shared<muon>("antimuon");
  std::shared_ptr<particle> tau1 = std::make_shared<tau>("tau");
  std::shared_ptr<particle> antitau1 = std::make_shared<tau>("antitau");
  std::shared_ptr<particle> electron_neutrino1 = std::make_shared<neutrino>("electron_neutrino");
  std::shared_ptr<particle> antielectron_neutrino1 = std::make_shared<neutrino>("antielectron_neutrino");
  std::shared_ptr<particle> muon_neutrino1 = std::make_shared<neutrino>("muon_neutrino");
  std::shared_ptr<particle> antimuon_neutrino1 = std::make_shared<neutrino>("antimuon_neutrino");
  std::shared_ptr<particle> tau_neutrino1 = std::make_shared<neutrino>("tau_neutrino");
  std::shared_ptr<particle> antitau_neutrino1 = std::make_shared<neutrino>("antitau_neutrino");
  std::shared_ptr<particle> higgs_boson1 = std::make_shared<higgs_boson>("default");
  std::shared_ptr<particle> w_minus1 = std::make_shared<w_boson>("w_minus");
  std::shared_ptr<particle> w_plus1 = std::make_shared<w_boson>("w_plus");
  std::shared_ptr<particle> z_boson1 = std::make_shared<z_boson>("default");
  std::shared_ptr<particle> gluon_1 = std::make_shared<gluon>("default");
  std::shared_ptr<particle> photon_1 = std::make_shared<photon>("default");

  four_momentum up_four_momenta(4, 2, 2, 2);
  four_momentum down_four_momenta(10, 5, 5, 5);
  four_momentum charm_four_momenta(1405, 720, 377, 560);
  four_momentum strange_four_momenta(108, 37, 11, 34);
  four_momentum top_four_momenta(223158, 63500, 94600, 83000);
  four_momentum bottom_four_momenta(4941, 1401, 1900, 1170);
  four_momentum electron_four_momenta(2, 1, 1, 1);
  four_momentum muon_four_momenta(159, 86, 43, 69);
  four_momentum tau_four_momenta(2130, 520, 300, 420);
  four_momentum massless_four_momenta(5, 4, 3, 0);
  four_momentum higgs_four_momenta(134000, 22000, 37700, 20633);
  four_momentum w_four_momenta(88058, 10900, 29698, 18800);
  four_momentum z_four_momenta(102642, 19800, 37700, 21000);

  // setting suitable physical four-momenta to each particle
  up_quark1->set_four_momenta(up_four_momenta);
  antiup_quark1->set_four_momenta(up_four_momenta);
  electron1->set_four_momenta(electron_four_momenta);
  antielectron1->set_four_momenta(electron_four_momenta);
  muon1->set_four_momenta(muon_four_momenta);
  antimuon1->set_four_momenta(muon_four_momenta);
  tau1->set_four_momenta(tau_four_momenta);
  antitau1->set_four_momenta(tau_four_momenta);
  electron_neutrino1->set_four_momenta(massless_four_momenta);
  antielectron_neutrino1->set_four_momenta(massless_four_momenta);
  muon_neutrino1->set_four_momenta(massless_four_momenta);
  antimuon_neutrino1->set_four_momenta(massless_four_momenta);
  tau_neutrino1->set_four_momenta(massless_four_momenta);
  antitau_neutrino1->set_four_momenta(massless_four_momenta);
  higgs_boson1->set_four_momenta(higgs_four_momenta);
  w_minus1->set_four_momenta(w_four_momenta);
  w_plus1->set_four_momenta(w_four_momenta);
  z_boson1->set_four_momenta(z_four_momenta);
  gluon_1->set_four_momenta(massless_four_momenta);
  photon_1->set_four_momenta(massless_four_momenta);

  // making a particle container and adding all particles
  container particle_container;

  particle_container.add_to_container(up_quark1);
  particle_container.add_to_container(antiup_quark1);
  particle_container.add_to_container(electron1);
  particle_container.add_to_container(antielectron1);
  particle_container.add_to_container(muon1);
  particle_container.add_to_container(antimuon1);
  particle_container.add_to_container(tau1);
  particle_container.add_to_container(antitau1);
  particle_container.add_to_container(electron_neutrino1);
  particle_container.add_to_container(antielectron_neutrino1);
  particle_container.add_to_container(muon_neutrino1);
  particle_container.add_to_container(antimuon_neutrino1);
  particle_container.add_to_container(tau_neutrino1);
  particle_container.add_to_container(antitau_neutrino1);
  particle_container.add_to_container(higgs_boson1);
  particle_container.add_to_container(w_minus1);
  particle_container.add_to_container(w_plus1);
  particle_container.add_to_container(z_boson1);
  particle_container.add_to_container(gluon_1);
  particle_container.add_to_container(photon_1);

  // printing the number of particles of each separate type
  particle_container.get_number_of_contents_by_particle_type();

  // summing up all four-momenta inside the container
  std::vector<float> four_vector_components_summed;
  four_vector_components_summed = particle_container.four_momentum_container_sum();

  // displaying a decay and the printing function
  higgs_boson higgs_decay_example("default");
  higgs_decay_example.get_higgs_decay_products("ZZ");
  higgs_decay_example.particle_printing_function();

  return 0;
}