// C++ final project: quarks class header file

#include "4_quarks.h"

quark::quark(std::string flavour_input)
{
  if(flavour_input == "up" || flavour_input == "charm" || flavour_input == "top")
  {
    flavour = flavour_input;
    charge = 2.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "down" || flavour_input == "strange" || flavour_input == "bottom")
  {
    flavour = flavour_input;
    charge = -1.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antiup" || flavour_input == "anticharm" || flavour_input == "antitop")
  {
    flavour = flavour_input;
    charge = -2.0/3.0;
    baryon_number = -1.0/3.0;
    lepton_number= 0;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antidown" || flavour_input == "antistrange" || flavour_input == "antibottom")
  {
    flavour = flavour_input;
    charge = 1.0/3.0;
    baryon_number = -1.0/3.0;
    lepton_number= 0;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour entered is invalid. Setting flavour to up. " << std::endl;
    flavour = "up";
    charge = 2.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

// setters and getters
void quark::set_flavour(std::string flavour_input)
{
  if(flavour_input == "up" || flavour_input == "charm" || flavour_input == "top")
  {
    flavour = flavour_input;
    charge = 2.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "down" || flavour_input == "strange" || flavour_input == "bottom")
  {
    flavour = flavour_input;
    charge = -1.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antiup" || flavour_input == "anticharm" || flavour_input == "antitop")
  {
    flavour = flavour_input;
    charge = -2.0/3.0;
    baryon_number = -1.0/3.0;
    lepton_number= 0;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antidown" || flavour_input == "antistrange" || flavour_input == "antibottom")
  {
    flavour = flavour_input;
    charge = 1.0/3.0;
    baryon_number = -1.0/3.0;
    lepton_number= 0;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour entered is invalid. Setting flavour to up. " << std::endl;
    flavour = "up";
    charge = 2.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

void quark::set_charge(float charge_input)
{
  spin = 1.0/2.0;
  if(charge_input == 2.0/3.0 || charge_input == -1.0/3.0)
  {
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
  }
  else if(charge_input == -2.0/3.0 || charge_input == 1.0/3.0)
  {
    baryon_number = -1.0/3.0;
    lepton_number= 0;
    antimatter_status = 1;
  }
  else
  {
    std::cout << "The charge value inputted is invalid. Setting charge to +2/3." << std::endl;
    charge == 2.0/3.0;
    baryon_number = 1.0/3.0;
    lepton_number= 0;
    antimatter_status = 0;
  }
};

void quark::set_colour(std::string colour_input)
{
  spin = 1.0/2.0;

  if((colour_input == "red" || colour_input == "blue" || colour_input == "green") && antimatter_status == 0)
  {
    colour = colour_input;
  }
  else if((colour_input == "antired" || colour_input == "antiblue" || colour_input == "antigreen") && antimatter_status == 1)
  {
    colour = colour_input;
  }
  else
  {
    std::cout << "Colour inputted is invalid. Setting colour to red. " << std::endl;
    colour = "red";
  }
};

void quark::set_mass()
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if((flavour == "up" || flavour == "antiup") && (invariant_mass_value == up_mass)) {mass = invariant_mass_value;}
  else if((flavour == "down" || flavour == "antidown") && (invariant_mass_value == down_mass)) {mass = invariant_mass_value;}
  else if((flavour == "charm" || flavour == "anticharm") && (invariant_mass_value == charm_mass)) {mass = invariant_mass_value;}
  else if((flavour == "strange" || flavour == "antistrange") && (invariant_mass_value == strange_mass)) {mass = invariant_mass_value;}
  else if((flavour == "top" || flavour == "antitop") && (invariant_mass_value == top_mass)) {mass = invariant_mass_value;}
  else if((flavour == "bottom" || flavour == "antibottom") && (invariant_mass_value == bottom_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;

    if(flavour == "up" || flavour == "antiup")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(4, 2, 2, 2);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else if(flavour == "down" || flavour == "antidown")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(10, 5, 5, 5);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else if(flavour == "charm" || flavour == "anticharm")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(1405, 720, 377, 560);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else if(flavour == "strange" || flavour == "antistrange")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(108, 37, 11, 34);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else if(flavour == "top" || flavour == "antitop")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(223158, 63500, 94600, 83000);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else if(flavour == "bottom" || flavour == "antibottom")
    {
      std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Scaling the four-momentum. " << std::endl;
      four_momentum_vector.set_e_px_py_pz(4941, 1401, 1900, 1170);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
    else
    {
      std::cout << "No valid flavour has been set to this particle. Setting flavour to up and setting an appropriate four-momenta. " << std::endl;
      flavour = "up";
      four_momentum_vector.set_e_px_py_pz(4, 2, 2, 2);
      new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
      mass = new_invariant_mass;
    }
  }
};

void quark::particle_printing_function() 
{
  std::cout << "Printing quark information." << std::endl;
  fermion::particle_printing_function();
  std::cout << "Quark flavour: " << get_flavour() << "; mass: " << get_mass() << "; colour:" << get_colour() << "; baryon number: " << get_baryon_number() << ". \n" << std::endl;
};