// C++ final project: W boson class header file

#ifndef W_BOSON_H
#define W_BOSON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "12_vector_boson.h"

const float w_mass = 80.0*std::pow(10, 3);

class w_boson: public vector_boson
{
  private:
    std::vector<std::shared_ptr<particle>> decay_products_vector;
  public:
    w_boson() = default;
    w_boson(std::string flavour_input);
    ~w_boson(){ };
    // member functions
    void set_flavour(std::string flavour_input);

    void set_charge(float charge_input) override ;

    void set_mass() override ;

    void get_w_decay_products(std::string decay_flavour);

    std::vector<std::shared_ptr<particle>> access_w_decay_products() {return decay_products_vector;};

    void particle_printing_function() override ;
};

#endif