// C++ final project: gluon class header file

#ifndef GLUON_H
#define GLUON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "12_vector_boson.h"

class gluon: public vector_boson
{
  private:
    std::vector<std::string> flavour_combination;
  public:
    gluon() = default;
    gluon(std::string flavour_input);
    ~gluon(){ };
    // member functions
    void set_gluon_colour(std::string flavour1, std::string flavour2);

    void set_charge(float charge_input) override ;
    
    void set_flavour(std::string flavour_input) override ;

    void set_mass() override ;

    std::vector<std::string> get_gluon_colour() {return flavour_combination;};

    void particle_printing_function() override ;
};

#endif