// C++ final project: neutrino class cpp file

#include "9_neutrino.h"

// parameterised constructor
neutrino::neutrino(std::string flavour_input)
{
  charge = 0;
  if (flavour_input == "electron_neutrino" || flavour_input == "muon_neutrino" || flavour_input == "tau_neutrino")
  {
    flavour = flavour_input;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antielectron_neutrino" || flavour_input == "antimuon_neutrino" || flavour_input == "antitau_neutrino")
  {
    flavour = flavour_input;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting neutrino flavour to electron neutrino. " << std::endl;
    flavour = "electron_neutrino";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

// setters and getters
void neutrino::set_flavour(std::string flavour_input)
{
  charge = 0;
  if (flavour_input == "electron_neutrino" || flavour_input == "muon_neutrino" || flavour_input == "tau_neutrino")
  {
    flavour = flavour_input;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antielectron_neutrino" || flavour_input == "antimuon_neutrino" || flavour_input == "antitau_neutrino")
  {
    flavour = flavour_input;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting neutrino flavour to electron neutrino. " << std::endl;
    flavour = "electron_neutrino";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

void neutrino::set_interaction(bool interaction_value)
{
  if (interaction_value == 1)
  {
    hasInteracted = interaction_value;
    std::cout << "The neutrino has interacted. " << std::endl;
  }
  else if (interaction_value == 0)
  {
    hasInteracted = interaction_value;
    std::cout << "The neutrino has not interacted. " << std::endl;
  }
  else
  {
    std::cout << "An invalid value was inputted. Setting interaction to true. " << std::endl;
    hasInteracted = 1;
  }
};

void neutrino::set_charge(float charge_input)
{
  if(charge_input == 0)
  {
    charge = charge_input;
    baryon_number = 0.0;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "The charge value entered is invalid. Setting the charge to zero. " << std::endl;
    charge = 0;
    baryon_number = 0.0;
    spin = 1.0/2.0;
  }
};

void neutrino::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == 0)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(5, 4, 3, 0);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void neutrino::particle_printing_function() 
{
  if(hasInteracted == 0)
  {
    std::cout << "Printing neutrino information. " << std::endl;
    lepton::particle_printing_function();
    std:: cout << "Flavour: " << get_flavour() << " neutrino; interaction status: false." << std::endl;
  }
  else if(hasInteracted == 1)
  {
    std::cout << "Printing neutrino information. " << std::endl;
    lepton::particle_printing_function();
    std:: cout << "Flavour: " << get_flavour() << " neutrino; interaction status: true." << std::endl;
  }
  else
  {
    std::cout << "Particle does not have all attributes associated. " << std::endl;
  }
};