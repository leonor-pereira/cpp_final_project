// C++ final project: Z boson class cpp file

#include "14_z_boson.h"

// parameterised constructor
z_boson::z_boson(std::string flavour_input)
{
  if(flavour_input == "default")
  {
    flavour = "Z_boson";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "No non-Standard Model Z bosons are available. Creating a Standard Model Z boson. " << std::endl;
    flavour = "Z_boson";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;    
  }
};

// setters and getters
void z_boson::set_flavour(std::string flavour_input)
{
  if(flavour_input == "Z_boson")
  {
    flavour = flavour_input;
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting the flavour to Z boson. " << std::endl;
    flavour = "Z_boson";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;    
  }
};

void z_boson::set_charge(float charge_input)
{
  if(charge_input = 0)
  {
    flavour = "Z_boson";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;    
  }
  else
  {
    std::cout << "The charge value entered is invalid. Setting the charge to zero. " << std::endl;
    flavour = "Z_boson";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;    
  }
};

void z_boson::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == z_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(102642, 19800, 37700, 21000);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void z_boson::particle_printing_function() 
{
  std::cout << "Printing Z boson information. " << std::endl;
  vector_boson::particle_printing_function();
  std::cout << "Printing Z boson decay information. " << std::endl;

  for(int i = 0; i < decay_products_vector.size(); i++)
  {
    std::cout << "Flavour: " << (decay_products_vector.at(i))->get_flavour() << "; charge: " << (decay_products_vector.at(i))->get_charge() << "; spin: " << (decay_products_vector.at(i))->get_spin() << ". " << std::endl;
  }
};