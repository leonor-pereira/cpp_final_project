// C++ final project: neutrino class header file

#ifndef NEUTRINO_H
#define NEUTRINO_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "5_lepton.h"

class neutrino: public lepton
{
  private:
    bool hasInteracted;
  public:
    neutrino() = default;
    neutrino(std::string flavour_input);
    ~neutrino(){ };
    void set_flavour(std::string flavour_input) override ;

    void set_interaction(bool interaction_value);

    void set_charge(float charge_input);

    void set_mass() override ;

    bool get_interaction() const {return hasInteracted;};

    void particle_printing_function() override ;
};

#endif