// C++ final project: fermion class header file

#ifndef FERMION_H
#define FERMION_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"

class fermion: public particle
{
  public:
    fermion() = default;
    ~fermion(){ };
    // member functions
    void particle_printing_function() override;
};

#endif