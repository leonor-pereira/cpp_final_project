// C++ final project: tau class header file

#ifndef TAU_H
#define TAU_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "5_lepton.h"

const float tau_mass = 2.0*std::pow(10, 3);

class tau: public lepton
{
  private:
    std::vector<std::shared_ptr<particle>> decay_products_vector;
  public:
    tau() = default;
    tau(std::string flavour_input);
    ~tau(){ };
    //member functions
    void set_flavour(std::string flavour_input) override ;

    void set_charge(float charge_input) override ;

    void set_mass() override ;

    void get_tau_decay_products(std::string decay_flavour);

    std::vector<std::shared_ptr<particle>> access_tau_decay_products() {return decay_products_vector;};

    void particle_printing_function() override ;
};

#endif