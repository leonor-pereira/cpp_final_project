// C++ final project: gluon class cpp file

#include "15_gluon.h"

// parameterised constructor
gluon::gluon(std::string flavour_input)
{
  if(flavour_input == "default")
  {
    flavour = "gluon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
    antimatter_status = 0;
  }
  else
  {
    std::cout << "No non-Standard Model gluons are available. Creating a Standard Model gluon. " << std::endl;
    flavour = "gluon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
    antimatter_status = 1;
  }
};

// setters and getters
void gluon::set_gluon_colour(std::string flavour1, std::string flavour2)
{
  flavour = "gluon";
  charge = 0.0;
  spin = 1.0;
  baryon_number = 0;
  lepton_number = 0;

  if((flavour1 == "red" && flavour2 == "antiblue") || (flavour1 == "red" && flavour2 == "antigreen") || (flavour1 == "blue" && flavour2 == "antired") || (flavour1 == "blue" && flavour2 == "antigreen") || (flavour1 == "green" && flavour2 == "antired") || (flavour1 == "green" && flavour2 == "antiblue"))
  {
    flavour_combination.at(0) = flavour1;
    flavour_combination.at(1) = flavour2;
  }
  else
  {
    std::cout << "The colour combination entered is invalid. Setting the gluon's colours red and antiblue. " << std::endl;
    flavour_combination.at(0) = "red";
    flavour_combination.at(1) = "antiblue"; 
  }
};

void gluon::set_charge(float charge_input) 
{
  if(charge_input == 0)
  {
    charge = charge_input;
    flavour = "gluon";
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;   
  }
  else
  {
    std::cout << "The charge value entered is invalid. Setting the charge to zero. " << std::endl;
    charge = 0.0;
    flavour = "gluon";
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void gluon::set_flavour(std::string flavour_input)     
{
  if(flavour_input == "gluon")
  {
    flavour = flavour_input;
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting the flavour to gluon. " << std::endl;
    flavour = "gluon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void gluon::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == 0)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(5, 4, 3, 0);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void gluon::particle_printing_function() 
{
  std::cout << "Printing gluon information. " << std::endl;
  vector_boson::particle_printing_function();
  std::cout << "Colour combination: " << flavour_combination.at(0) << " and " << flavour_combination.at(1) << ". " << std::endl;
};