// C++ final project: lepton class cpp file

#include "5_lepton.h"

void lepton::particle_printing_function() 
{
  fermion::particle_printing_function();
  std::cout << "Lepton number: " << get_lepton_number() <<  std::endl;
};