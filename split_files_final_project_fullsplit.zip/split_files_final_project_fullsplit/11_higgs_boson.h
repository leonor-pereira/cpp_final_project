// C++ final project: higgs boson class header file

#ifndef HIGGS_BOSON_H
#define HIGGS_BOSON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "10_scalar_boson.h"

const float higgs_mass = 125.0*std::pow(10, 3);

class higgs_boson: public scalar_boson
{
  private:
    std::vector<std::shared_ptr<particle>> decay_products_vector;
  public:
    higgs_boson() = default;
    higgs_boson(std::string flavour_input);
    ~higgs_boson(){ };
    // member functions
    void set_charge(float charge_input) override ;

    void set_flavour(std::string flavour_input) override ;

    void set_mass() override ;

    void get_higgs_decay_products(std::string decay_flavour);

    std::vector<std::shared_ptr<particle>> access_higgs_decay_products() {return decay_products_vector;};

    void particle_printing_function() override ;
};

#endif