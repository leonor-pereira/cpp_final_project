// C++ final project: Z boson class header file

#ifndef Z_BOSON_H
#define Z_BOSON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "12_vector_boson.h"

const float z_mass = 91.0*std::pow(10, 3);

class z_boson: public vector_boson
{
  private:
    std::vector<std::shared_ptr<particle>> decay_products_vector;
  public:
    z_boson() = default;
    z_boson(std::string flavour_input);
    ~z_boson(){ };
    // member functions
    void set_flavour(std::string flavour_input) override ;

    void set_charge(float charge_input) override ;

    void set_mass() override ;

    void get_z_decay_products(std::string decay_flavour);

    std::vector<std::shared_ptr<particle>> access_z_decay_products() {return decay_products_vector;};

    void particle_printing_function() override ;
};

#endif