// C++ final project: electron class header file

#include "6_electron.h"

// parameterised constructor
electron::electron(std::string particle_type)
{
  if(particle_type == "electron")
  {
    flavour = particle_type;
    charge = -1.0;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(particle_type == "antielectron")
  {
    flavour = particle_type;
    charge = 1.0;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "The flavour inputted is invalid. Setting flavour to electron. " << std::endl;
    flavour = "electron";
    charge = -1.0;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }    
};

//setters and getters
void electron::set_energy_deposited(four_momentum four_vec, float em_1_deposited, float em_2_deposited, float had_1_deposited, float had_2_deposited)
{
  float energy_sum;
  energy_sum = em_1_deposited + em_2_deposited + had_1_deposited + had_2_deposited;

  if (energy_sum == four_vec.get_energy())
  {
    (*energy_deposited).at(0) = em_1_deposited;
    (*energy_deposited).at(1) = em_2_deposited;
    (*energy_deposited).at(2) = had_1_deposited;
    (*energy_deposited).at(3) = had_2_deposited;
  }
  else
  {
    std::cout << "The four vector entered and the deposited energies do not match. Correcting values. " << std::endl;
    float correcting_factor = (four_vec.get_energy())/energy_sum;
    (*energy_deposited).at(0) = em_1_deposited*correcting_factor;
    (*energy_deposited).at(1) = em_2_deposited*correcting_factor;
    (*energy_deposited).at(2) = had_1_deposited*correcting_factor;
    (*energy_deposited).at(3) = had_2_deposited*correcting_factor;
  }
};

void electron::set_flavour(std::string flavour_input)
{
  if(flavour_input == "electron")
  {
    flavour = flavour_input;
    charge = -1.0;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if(flavour_input == "antielectron")
  {
    flavour = flavour_input;
    charge = 1.0;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "The flavour inputted is invalid. Setting flavour to electron. " << std::endl;
    flavour = "electron";
    charge = -1.0;
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

void electron::set_charge(float charge_input)
{
  if (charge_input==-1)
  {
    charge = charge_input;
    flavour = "electron";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (charge_input==+1)
  {
    charge = charge_input;
    flavour = "antielectron";
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Charge value inputted is invalid. Setting charge to -1. " << std::endl;
    charge = -1.0;
    flavour = "electron";    
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;    
  }
};

void electron::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == electron_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(2, 1, 1, 1);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void electron::particle_printing_function() 
{
  std::cout << "Printing electron information. " << std::endl;
  lepton::particle_printing_function();
  std::cout << "Flavour: " << get_flavour() << ". " << "Energy deposited in calorimeter. Electromagnetic 1st layer component: " << (*energy_deposited).at(0) << "; electromagnetic 2nd layer component: " << (*energy_deposited).at(1) << "; hadronic 1st layer component: " << (*energy_deposited).at(2) << "; hadronic 2nd layer component: " << (*energy_deposited).at(3) << ". \n" <<  std::endl;
};