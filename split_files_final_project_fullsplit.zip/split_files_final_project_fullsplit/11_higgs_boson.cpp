// C++ final project: higgs boson class cpp file

#include "11_higgs_boson.h"

// parameterised constructor
higgs_boson::higgs_boson(std::string flavour_input)
{
  if(flavour_input == "default")
  {
    flavour = "higgs_boson";
    charge = 0.0;
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "No non-Standard Model Higgs bosons are available. Creating a Standard Model Higgs boson. " << std::endl;
    flavour = "higgs_boson";
    charge = 0.0;
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;    
  }
};

// setters and getters
void higgs_boson::set_charge(float charge_input) 
{
  if(charge_input == 0)
  {
    charge = charge_input;
    flavour = "higgs_boson";
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;   
  }
  else
  {
    std::cout << "The charge value entered is invalid. Setting the charge to zero. " << std::endl;
    charge = 0.0;
    flavour = "higgs_boson";
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void higgs_boson::set_flavour(std::string flavour_input)
{
  if(flavour == "higgs_boson")
  {
    charge = 0.0;
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting the flavour to Higgs boson. " << std::endl;
    flavour = "higgs_boson";
    charge = 0.0;
    spin = 0.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void higgs_boson::set_mass()
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == higgs_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(134000, 22000, 37700, 20633);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void higgs_boson::particle_printing_function() 
{
  std::cout << "Printing Higgs boson information. " << std::endl;
  scalar_boson::particle_printing_function();
  std::cout << "Printing Higgs boson decay information. " << std::endl;

  for(int i = 0; i < decay_products_vector.size(); i++)
  {
    std::cout << "Flavour: " << (decay_products_vector.at(i))->get_flavour() << "; charge: " << (decay_products_vector.at(i))->get_charge() << "; spin: " << (decay_products_vector.at(i))->get_spin() << ". " << std::endl;
  }
}