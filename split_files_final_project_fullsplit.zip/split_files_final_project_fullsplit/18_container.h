// C++ final project: container class header file

#ifndef CONTAINER_H
#define CONTAINER_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"
#include "4_quarks.h"
#include "5_lepton.h"
#include "6_electron.h"
#include "7_muon.h"
#include "8_tau.h"
#include "9_neutrino.h"
#include "10_scalar_boson.h"
#include "11_higgs_boson.h"
#include "12_vector_boson.h"
#include "13_w_boson.h"
#include "14_z_boson.h"
#include "15_gluon.h"
#include "16_photon.h"

class container
{
  private:
    std::vector<std::shared_ptr<particle>> container_contents;
  public:
    // constructors and destructors
    container() = default;
    ~container(){ };

    // member functions
    void add_to_container(std::shared_ptr<particle> input_particle) {container_contents.push_back(input_particle);};

    int get_number_of_contents() {return container_contents.size();};

    void get_number_of_contents_by_particle_type();

    std::vector<float> four_momentum_container_sum();
};

#endif