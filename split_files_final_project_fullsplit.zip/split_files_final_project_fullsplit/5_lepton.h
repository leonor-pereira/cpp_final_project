// C++ final project: lepton class header file

#ifndef LEPTON_H
#define LEPTON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"
#include "3_fermion.h"

class lepton: public fermion
{
  public:
    lepton() = default;
    ~lepton(){ };
    // member functions
    void particle_printing_function() override ;
};

#endif