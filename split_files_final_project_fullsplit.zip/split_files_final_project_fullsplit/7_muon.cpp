// C++ final project: muon class cpp file

#include "7_muon.h"

// parametrised constructor
muon::muon(std::string flavour_input)
{
  if (flavour_input == "muon")
  {
    flavour = flavour_input;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (flavour_input == "antimuon")
  {
    flavour = flavour_input;
    charge = +1;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to muon. " << std::endl;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

// setters and getters
void muon::set_isolation(bool isolation_value)
{
  if (isolation_value == 1)
  {
    isolation = isolation_value;
    std::cout << "The muon is isolated. " << std::endl;
  }
  else if (isolation_value == 0)
  {
    isolation = isolation_value;
    std::cout << "The muon is not isolated. " << std::endl;
  }
  else
  {
    std::cout << "An invalid value was inputted. Setting isolation to true. " << std::endl;
    isolation = 1;
  }
};

void muon::set_charge(float charge_input)
{
  if (charge_input==-1)
  {
    charge = charge_input;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (charge_input==+1)
  {
    charge = charge_input;
    flavour = "antimuon";
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Charge value inputted is invalid. Setting charge to -1. " << std::endl;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;   
  }
};

void muon::set_flavour(std::string flavour_input)
{
  if (flavour_input == "muon")
  {
    flavour = flavour_input;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
  else if (flavour_input == "antimuon")
  {
    flavour = flavour_input;
    charge = +1;
    baryon_number = 0.0;
    lepton_number = -1;
    antimatter_status = 1;
    spin = 1.0/2.0;
  }
  else
  {
    std::cout << "Flavour inputted is invalid. Setting flavour to muon. " << std::endl;
    charge = -1;
    flavour = "muon";
    baryon_number = 0.0;
    lepton_number = 1;
    antimatter_status = 0;
    spin = 1.0/2.0;
  }
};

void muon::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == muon_mass)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(159, 86, 43, 69);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void muon::particle_printing_function() 
{
  if(isolation == 0)
  {
    std::cout << "Printing muon information. " << std::endl;
    lepton::particle_printing_function();
    std:: cout << "Flavour: " << get_flavour() << "; isolation status: false." << std::endl;
  }
  else if(isolation == 1)
  {
    std::cout << "Printing muon information. " << std::endl;
    lepton::particle_printing_function();
    std:: cout << "Flavour: " << get_flavour() << "; isolation status: true." << std::endl;
  }
  else
  {
    std::cout << "Particle does not have all attributes associated. " << std::endl;
  }
};