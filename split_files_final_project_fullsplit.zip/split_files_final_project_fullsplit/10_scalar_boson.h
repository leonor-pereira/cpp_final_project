// C++ final project: scalar boson class header file

#ifndef SCALAR_BOSON_H
#define SCALAR_BOSON_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cmath>

#include "1_four_momentum.h"
#include "2_particle.h"

class scalar_boson: public particle
{
  public:
    scalar_boson() = default;
    ~scalar_boson(){ };
    // member functions
    void particle_printing_function() override ;
};

#endif