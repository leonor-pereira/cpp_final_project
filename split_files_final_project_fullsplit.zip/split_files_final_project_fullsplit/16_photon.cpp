// C++ final project: photon class cpp file

#include "16_photon.h"

// parameterised constructor
photon::photon(std::string flavour_input)
{
  if(flavour_input == "default")
  {
    flavour = "photon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
  else
  {
    std::cout << "No non-Standard Model photons are available. Creating a Standard Model photon. " << std::endl;
    flavour = "photon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0;
    lepton_number = 0;
  }
};

// setters and getters
void photon::set_charge(float charge_input) 
{
  if(charge_input == 0)
  {
    charge = charge_input;
    flavour = "photon";
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;   
  }
  else
  {
    std::cout << "The charge value entered is invalid. Setting the charge to zero. " << std::endl;
    charge = 0.0;
    flavour = "photon";
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void photon::set_flavour(std::string flavour_input)     
{
  if(flavour_input == "photon")
  {
    flavour = flavour_input;
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
  else
  {
    std::cout << "The flavour entered is invalid. Setting the flavour to photon. " << std::endl;
    flavour = "photon";
    charge = 0.0;
    spin = 1.0;
    baryon_number = 0.0;
    lepton_number = 0;  
  }
};

void photon::set_mass() 
{
  float invariant_mass_value = four_momentum_vector.invariant_mass_calculation();

  if ((invariant_mass_value == 0)) {mass = invariant_mass_value;}
  else
  {
    float new_invariant_mass;
    std::cout << "The invariant mass calculated from this particle's four-momentum does not match the expected mass value. Setting an appropriate four-momentum. " << std::endl;
    four_momentum_vector.set_e_px_py_pz(5, 4, 3, 0);
    new_invariant_mass = four_momentum_vector.invariant_mass_calculation();
    mass = new_invariant_mass;
  }      
};

void photon::particle_printing_function() 
{
  std::cout << "Printing photon information. " << std::endl;
  vector_boson::particle_printing_function();
};